package com.example.photoreminder

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

class PhotoAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("photos", Context.MODE_PRIVATE)
        val list = prefs.getStringSet("uris", emptySet())?.toList().orEmpty()
        if (list.isNotEmpty()) {
            val index = prefs.getInt("index", 0) % list.size
            showPhoto(context, Uri.parse(list[index]))
            prefs.edit().putInt("index", (index + 1) % list.size).apply()
        }
        if (prefs.getBoolean("running", false) && list.isNotEmpty()) ReminderScheduler.schedule(context)
    }
    private fun showPhoto(context: Context, uri: Uri) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = "photo_reminders"
        if (Build.VERSION.SDK_INT >= 26)
            manager.createNotificationChannel(NotificationChannel(channel, "Photo reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val content = PendingIntent.getActivity(context, 1, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val bitmap = try { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
        val builder = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("عکس جدید برای شما").setContentText("برای باز کردن برنامه لمس کنید")
            .setContentIntent(content).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT)
        if (bitmap != null) builder.setLargeIcon(bitmap).setStyle(NotificationCompat.BigPictureStyle().bigPicture(bitmap))
        manager.notify(9001, builder.build())
    }
}
